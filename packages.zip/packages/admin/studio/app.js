// This file is auto-generated from "atria dev".
// Modifications to this file are automatically discarded.

import { mountAdminApp } from "/static/app.js";

const rootElement = document.getElementById("atria");

const readInitialAppState = async () => {
  try {
    const response = await fetch("/admin/bootstrap", { method: "GET" });
    if (!response.ok) {
      return {
        realm: "critical",
        screen: "server-down"
      };
    }

    const payload = await response.json();
    if (
      payload?.state === "setup" ||
      payload?.state === "create" ||
      payload?.state === "login" ||
      payload?.state === "broker-consent"
    ) {
      return {
        realm: "auth",
        screen: payload.state
      };
    }

    if (payload?.state !== "authenticated") {
      return {
        realm: "critical",
        screen: "server-down"
      };
    }

    const user = payload.user;
    if (
      !user ||
      typeof user.name !== "string" ||
      typeof user.email !== "string" ||
      typeof user.avatarUrl !== "string" ||
      typeof user.role !== "string"
    ) {
      return undefined;
    }

    return {
      realm: "studio",
      screen: "dashboard",
      user
    };
  } catch {
    if (!window.navigator.onLine) {
      return {
        realm: "critical",
        screen: "offline"
      };
    }

    return {
      realm: "critical",
      screen: "server-down"
    };
  }
};

void (async () => {
  const initialAppState = await readInitialAppState();
  mountAdminApp({
    mountElement: rootElement,
    basePath: "/",
    reactStrictMode: false,
    initialAppState
  });
})();
